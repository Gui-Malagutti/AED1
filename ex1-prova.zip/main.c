/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int vet[50], i;

    for (i = 0; i<50 ; i++){
    printf("\ninsira o %dº numero: ", i + 1);
    scanf ("%d", &vet[i]);}

    printf("\nOs numeros digitados em ordem decrescente são: ");

    for (i = 49; i>=0 ; i--){
    printf("\n");
    printf("%d", vet[i]);}

    return 0;
}